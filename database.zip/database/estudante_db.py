import random
from datetime import datetime
import streamlit as st
from database.conexao import get_connection, run_query

def adicionar_estudante(matricula, nome, email, senha, data_nascimento, curso):
    CON = get_connection()
    if not CON: return None
    try:
        with CON.cursor() as cursor:
            id_usuario = random.randint(10000, 99999)
            query = "INSERT INTO Usuario (ID_Usuario, Nome, Senha, Data_Nascimento, Email) VALUES (%s, %s, %s, %s, %s);"
            cursor.execute(query, (id_usuario, nome, senha, data_nascimento, email.strip()))
            query = "INSERT INTO Estudante (Matricula, Saldo_RU, Curso, ID_Usuario) VALUES (%s, 0.00, %s, %s);"
            cursor.execute(query, (int(matricula), curso, id_usuario))
            CON.commit()
            return {"matricula": matricula, "email": email}
    except Exception as e:
        if CON: CON.rollback()
        st.error(f"Erro na transação de cadastro: {e}")
        return None
    finally:
        if CON: CON.close()

def saldo_atual(matricula):
    query = "SELECT Saldo_RU FROM Estudante WHERE Matricula = %s;"
    res = run_query(query, (matricula,), fetch=True)
    return float(res[0]['saldo_ru']) if res else 0.0

def historico_transacoes(matricula, limite=30):
    query = (
        "SELECT Valor AS valor_transacao, Data_Hora AS data_hora "
        "FROM Transacao WHERE Matricula = %s ORDER BY Data_Hora DESC LIMIT %s;"
    )
    return run_query(query, (matricula, limite), fetch=True) or []


# aqui usando a procedure
def recarregar_saldo(matricula, valor):
    query = "CALL pr_realizar_recarga(%s, %s);"
    return run_query(query, (int(matricula), float(valor)), fetch=False) is not None

def listar_estudantes_admin(limite=200):
    query = (
        "SELECT e.matricula, u.nome, u.email, e.curso, e.saldo_ru "
        "FROM Estudante e "
        "JOIN Usuario u ON u.id_usuario = e.id_usuario "
        "ORDER BY u.nome ASC "
        "LIMIT %s;"
    )
    return run_query(query, (limite,), fetch=True) or []


def definir_saldo_estudante(matricula, novo_saldo):
    CON = get_connection()
    if not CON:
        return False
    try:
        with CON.cursor() as cursor:
            cursor.execute(
                "UPDATE Estudante SET Saldo_RU = %s WHERE Matricula = %s;",
                (novo_saldo, matricula),
            )
            if cursor.rowcount == 0:
                CON.rollback()
                return False
            CON.commit()
            return True
    except Exception as e:
        if CON:
            CON.rollback()
        st.error(f"Erro ao atualizar saldo do estudante: {e}")
        return False
    finally:
        if CON:
            CON.close()


def remover_estudante_sistema(matricula):
    CON = get_connection()
    if not CON:
        return False
    try:
        with CON.cursor() as cursor:
            cursor.execute("SELECT ID_Usuario FROM Estudante WHERE Matricula = %s;", (matricula,))
            row = cursor.fetchone()
            if not row:
                CON.rollback()
                return False

            id_usuario = row[0]
            cursor.execute("DELETE FROM Usuario WHERE ID_Usuario = %s;", (id_usuario,))
            if cursor.rowcount == 0:
                CON.rollback()
                return False

            CON.commit()
            return True
    except Exception as e:
        if CON:
            CON.rollback()
        st.error(f"Erro ao remover estudante: {e}")
        return False
    finally:
        if CON:
            CON.close()